#pragma once
/*
  hardware_uno.h - implementazione hardware per Arduino UNO R3

  Pinout consigliato (modificabile qui, senza toccare logic.cpp):
  - Valvole (SSR input): D8 (Z1), D9 (Z2)
  - Sensori umidita' analogici: A0 (Z1), A1 (Z2)
  - STOP button (opzionale): D7 verso GND (INPUT_PULLUP)

  Nota: alimenta i sensori a 3.3V anche su UNO, cosi' l'uscita analogica e' sicura anche per ESP32 (hardware invariato).
*/

#include <Arduino.h>
#include <EEPROM.h>
#include "config.h"
#include "logic.h"

static const uint8_t PIN_VALVE[ZONE_COUNT] = {8, 9};
static const uint8_t PIN_SOIL[ZONE_COUNT]  = {A0, A1};
static const uint8_t PIN_STOP = 7;

inline const char* hwBoardName(){ return "Arduino UNO"; }

inline void hwInit(){
  pinMode(LED_BUILTIN, OUTPUT);
  for(uint8_t z=0; z<ZONE_COUNT; z++){
    pinMode(PIN_VALVE[z], OUTPUT);
    digitalWrite(PIN_VALVE[z], VALVE_ACTIVE_HIGH ? LOW : HIGH);
  }
  pinMode(PIN_STOP, INPUT_PULLUP);
}

inline void hwSetValve(uint8_t zone, bool on){
  if(zone >= ZONE_COUNT) return;
  uint8_t level = on ? (VALVE_ACTIVE_HIGH ? HIGH : LOW)
                     : (VALVE_ACTIVE_HIGH ? LOW  : HIGH);
  digitalWrite(PIN_VALVE[zone], level);
  digitalWrite(LED_BUILTIN, on ? HIGH : LOW);
}

inline uint16_t hwReadSoilRaw(uint8_t zone){
  if(zone >= ZONE_COUNT) return 0;
  return (uint16_t)analogRead(PIN_SOIL[zone]);
}

inline bool hwReadRainActive(){
  // non cablato nella versione base
  return false;
}

inline bool hwReadStopActive(){
  return digitalRead(PIN_STOP) == LOW; // premuto verso GND
}

inline bool hwLoadPersist(PersistData &out){
  EEPROM.get(0, out);
  // Validazione base: magic verrà controllato in logic.cpp
  return true;
}

inline bool hwSavePersist(const PersistData &in){
  EEPROM.put(0, in);
  return true;
}
