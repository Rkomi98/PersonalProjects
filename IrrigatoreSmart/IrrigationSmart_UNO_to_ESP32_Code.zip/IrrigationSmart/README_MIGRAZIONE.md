# Centralina Smart DIY 24VAC (Hunter) - UNO -> ESP32

## 1) Cosa ti serve
- Le parti sono nella BOM Excel: `DIY_Hunter_24VAC_SmartController_BOM.xlsx`
- Modalita' consigliata: *Parallelo reversibile* con deviatore 4PDT (Hunter <-> DIY)

## 2) Filosofia hardware (invariato)
- Sensori umidita': alimentali a **3.3V** (sia su UNO che su ESP32).
- Uscite valvole: **SSR AC 2 canali** con ingresso 3-32V (cosi' funziona sia con 5V che 3.3V).
- 1 elettrovalvola alla volta.

## 3) Compilazione / Caricamento
- Arduino IDE: apri `IrrigationSmart.ino`
- Seleziona la board:
  - `Arduino Uno` per la fase di sviluppo
  - `ESP32 Dev Module` (o simile) per la fase finale

## 4) Test passo-passo (consigliato)
### T0 - Solo MCU
1. Collega la board via USB.
2. Apri Serial Monitor a 115200.
3. Verifica che compaia `=== IrrigationSmart BOOT ===`.

### T1 - Sensori
1. Collega i 2 sensori (3.3V, GND, SIG su A0/A1 oppure GPIO34/35).
2. Muovi il sensore in aria e poi in acqua: i valori raw devono cambiare.
3. Calibra:
   - `cal 1 dry` con sensore in aria (secco)
   - `cal 1 wet` con sensore in terra molto bagnata (o acqua, per riferimento)
   - ripeti per zona 2.

### T2 - SSR senza valvole
1. Alimenta il lato 24VAC.
2. NON collegare le elettrovalvole.
3. Comando: `on 1 5` e misura che OUT Z1 commuti 24VAC verso COM. Ripeti con Z2.

### T3 - Valvole
1. Collega elettrovalvola Z1.
2. Comando: `on 1 60` -> deve aprire e poi chiudere.
3. Ripeti per Z2.

### T4 - Auto
1. `factoryreset` (se vuoi ripartire pulito) + calibra.
2. Lascia `manual mode` disattivo: riavvia la board.
3. Se umidita' sotto `start`, parte un ciclo; si ferma a `stop` o dopo `maxon`.

## 5) Migrazione UNO -> ESP32
1. **Non cambiare cablaggio** di sensori e SSR, cambia solo la board.
2. Sposta i fili dai pin UNO ai pin ESP32 (vedi `hardware_esp32.h`):
   - Valvole: 26/27
   - Sensori: 34/35 (ADC1)
   - STOP: 25
3. Ricompila per ESP32 e carica.
4. Rifai calibrazione (i raw cambiano tra UNO e ESP32).
5. Se vuoi usare Wi-Fi in futuro, lascia i sensori su ADC1 (gia' fatto) per evitare conflitti.

## 6) Note pratiche
- Se il tuo modulo relay e' "active LOW", imposta in `config.h`:
  - `VALVE_ACTIVE_HIGH = false;`
- Se vuoi abilitare rain sensor (Mini-Clik):
  - set `USE_RAIN_SENSOR = true` e implementa `hwReadRainActive()` con un ingresso digitale.
  - Vedi fonte Hunter: https://www.hunterirrigation.com/support/mini-clik-wiring
