#pragma once
/*
  config.h - configurazione comune UNO/ESP32 (board-agnostic)

  Fonti tecniche utili (per dubbi su correnti e compatibilita'):
  - Hunter Eco-Logic Cut Sheet (specifiche elettriche): https://www.hunterirrigation.com/sites/default/files/CA-Cutsheet-EcoLogic-EM.pdf
  - Hunter Solenoids (correnti inrush/holding e range tensione): https://www.hunterirrigation.com/irrigation-product/accessories/solenoids
  - Hunter Mini-Clik wiring (sensore pioggia): https://www.hunterirrigation.com/support/mini-clik-wiring
*/

#include <Arduino.h>

static const uint8_t ZONE_COUNT = 2;

// --- Logica irrigazione (default, modificabile via seriale) ---
static const uint8_t DEFAULT_START_PCT[ZONE_COUNT] = {35, 35}; // sotto questa % inizia a irrigare
static const uint8_t DEFAULT_STOP_PCT[ZONE_COUNT]  = {45, 45}; // sopra questa % si ferma

// ciclo/soak: irrigazione breve, poi pausa, poi rivaluta
static const uint16_t DEFAULT_MAX_ON_SEC[ZONE_COUNT] = {300, 300}; // max secondi ON per ciclo (5 min)
static const uint16_t DEFAULT_SOAK_SEC[ZONE_COUNT]   = {300, 300}; // pausa dopo ciclo (5 min)

// cooldown globale per evitare ripetizioni ravvicinate (minuti)
static const uint16_t DEFAULT_COOLDOWN_MIN = 240; // 4 ore

// sicurezza: tempo massimo assoluto per una singola sessione (secondi)
static const uint16_t ABSOLUTE_SESSION_LIMIT_SEC = 1800; // 30 min

// se true: mai piu' di una zona contemporaneamente
static const bool ENFORCE_ONE_ZONE_AT_TIME = true;

// Moduli relay/SSR: true se attivo HIGH (molti SSR 3-32V sono HIGH=ON), false se attivo LOW (alcuni relay board)
static const bool VALVE_ACTIVE_HIGH = true;

// Debug seriale
static const uint32_t SERIAL_BAUD = 115200;
static const uint32_t DEBUG_PRINT_EVERY_MS = 5000;

// Campionamento sensori
static const uint32_t SENSOR_READ_EVERY_MS = 2000;

// Opzionali (cablaggio su ingressi digitali se presenti)
static const bool USE_RAIN_SENSOR = false; // se true, hwReadRainActive() blocca irrigazione
static const bool USE_STOP_BUTTON = true;  // pulsante STOP (consigliato): blocca e chiude tutto
