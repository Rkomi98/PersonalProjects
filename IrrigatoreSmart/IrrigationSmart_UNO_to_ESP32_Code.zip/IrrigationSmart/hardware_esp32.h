#pragma once
/*
  hardware_esp32.h - implementazione hardware per ESP32 (Arduino-ESP32)

  Pinout consigliato (ADC1 only!):
  - Valvole (SSR input): GPIO26 (Z1), GPIO27 (Z2)
  - Sensori umidita' analogici (ADC1): GPIO34 (Z1), GPIO35 (Z2)  [solo input]
  - STOP button (opzionale): GPIO25 verso GND (INPUT_PULLUP)

  Nota importante: su ESP32, ADC2 confligge con Wi-Fi. Per evitare problemi, usa solo pin ADC1 (GPIO32-39).
*/

#include <Arduino.h>
#ifndef LED_BUILTIN
#define LED_BUILTIN 2
#endif
#include <Preferences.h>
#include "config.h"
#include "logic.h"

static const uint8_t PIN_VALVE[ZONE_COUNT] = {26, 27};
static const uint8_t PIN_SOIL[ZONE_COUNT]  = {34, 35};
static const uint8_t PIN_STOP = 25;

static Preferences prefs;

inline const char* hwBoardName(){ return "ESP32"; }

inline void hwInit(){
  pinMode(LED_BUILTIN, OUTPUT);

  for(uint8_t z=0; z<ZONE_COUNT; z++){
    pinMode(PIN_VALVE[z], OUTPUT);
    digitalWrite(PIN_VALVE[z], VALVE_ACTIVE_HIGH ? LOW : HIGH);
  }
  pinMode(PIN_STOP, INPUT_PULLUP);

  // ADC
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db); // fino a ~3.3V
  for(uint8_t z=0; z<ZONE_COUNT; z++){
    analogSetPinAttenuation(PIN_SOIL[z], ADC_11db);
  }

}

inline void hwSetValve(uint8_t zone, bool on){
  if(zone >= ZONE_COUNT) return;
  uint8_t level = on ? (VALVE_ACTIVE_HIGH ? HIGH : LOW)
                     : (VALVE_ACTIVE_HIGH ? LOW  : HIGH);
  digitalWrite(PIN_VALVE[zone], level);
  digitalWrite(LED_BUILTIN, on ? HIGH : LOW);
}

inline uint16_t hwReadSoilRaw(uint8_t zone){
  if(zone >= ZONE_COUNT) return 0;
  return (uint16_t)analogRead(PIN_SOIL[zone]); // 0..4095
}

inline bool hwReadRainActive(){
  // non cablato nella versione base
  return false;
}

inline bool hwReadStopActive(){
  return digitalRead(PIN_STOP) == LOW;
}

inline bool hwLoadPersist(PersistData &out){
  prefs.begin("irrig", true);
  size_t got = prefs.getBytes("cfg", &out, sizeof(PersistData));
  prefs.end();
  return got == sizeof(PersistData);
}

inline bool hwSavePersist(const PersistData &in){
  prefs.begin("irrig", false);
  prefs.putBytes("cfg", &in, sizeof(PersistData));
  prefs.end();
  return true;
}
