#pragma once
#include <Arduino.h>

struct PersistData {
  uint32_t magic;
  uint16_t version;
  int16_t dryRaw[2];
  int16_t wetRaw[2];
  uint8_t startPct[2];
  uint8_t stopPct[2];
  uint16_t maxOnSec[2];
  uint16_t soakSec[2];
  uint16_t cooldownMin;
};

void logicSetup();
void logicLoop();

// --- Interfaccia hardware (implementata in hardware_uno.h / hardware_esp32.h) ---
void hwInit();
const char* hwBoardName();

uint16_t hwReadSoilRaw(uint8_t zone);     // raw ADC
void     hwSetValve(uint8_t zone, bool on);
bool     hwReadRainActive();              // true se piove (contatto chiuso/aperto a seconda cablaggio)
bool     hwReadStopActive();              // true se STOP premuto

bool hwLoadPersist(PersistData &out);
bool hwSavePersist(const PersistData &in);
