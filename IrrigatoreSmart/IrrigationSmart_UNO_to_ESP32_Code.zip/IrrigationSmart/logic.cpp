#include "logic.h"
#include "config.h"

// Stato per zona
enum ZoneState : uint8_t { Z_IDLE=0, Z_WATERING=1, Z_SOAK=2, Z_ERROR=3 };

static PersistData gCfg;
static ZoneState   gState[ZONE_COUNT];
static uint32_t    gStateSinceMs[ZONE_COUNT];
static uint32_t    gLastWaterMs[ZONE_COUNT];      // fine ultima sessione (per cooldown)
static uint32_t    gSessionStartMs[ZONE_COUNT];   // inizio sessione (limite assoluto)
static uint32_t    gManualUntilMs[ZONE_COUNT];    // fine manuale (0 = non attivo)
static bool        gManualMode = false;

static uint16_t    gSoilRaw[ZONE_COUNT];
static float       gSoilPct[ZONE_COUNT];

static String      gLine;

static const uint32_t CFG_MAGIC = 0x5A17B00B;
static const uint16_t CFG_VERSION = 1;

static uint32_t nowMs() { return millis(); }

static float clampf(float v, float lo, float hi){
  if(v<lo) return lo;
  if(v>hi) return hi;
  return v;
}

static bool isCalibrated(uint8_t z){
  // calibrazione valida: dry e wet diversi almeno 50 counts
  int16_t d = gCfg.dryRaw[z];
  int16_t w = gCfg.wetRaw[z];
  return (abs(w - d) >= 50);
}

static float rawToPct(uint16_t raw, int16_t dry, int16_t wet){
  float denom = float(wet - dry);
  if (fabs(denom) < 1.0f) return NAN;
  float pct = (float(raw) - float(dry)) / denom * 100.0f;
  return clampf(pct, 0.0f, 100.0f);
}

static void valveAllOff(){
  for(uint8_t z=0; z<ZONE_COUNT; z++){
    hwSetValve(z, false);
    gState[z] = Z_IDLE;
    gStateSinceMs[z] = nowMs();
    gManualUntilMs[z] = 0;
  }
}

static bool isCooldownOk(uint8_t z){
  uint32_t elapsed = nowMs() - gLastWaterMs[z];
  uint32_t need = uint32_t(gCfg.cooldownMin) * 60UL * 1000UL;
  return elapsed >= need;
}

static bool anyZoneWatering(){
  for(uint8_t z=0; z<ZONE_COUNT; z++){
    if(gState[z]==Z_WATERING) return true;
  }
  return false;
}

static int driestZoneReady(){
  // ritorna indice della zona con % piu' bassa che richiede irrigazione e rispetta cooldown, altrimenti -1
  int best = -1;
  float bestPct = 101.0f;
  for(uint8_t z=0; z<ZONE_COUNT; z++){
    if(gState[z] != Z_IDLE) continue;
    if(!isCalibrated(z)) continue;              // sicurezza: senza calibrazione niente AUTO
    if(!isfinite(gSoilPct[z])) continue;
    if(gSoilPct[z] < float(gCfg.startPct[z]) && isCooldownOk(z)){
      if(gSoilPct[z] < bestPct){
        bestPct = gSoilPct[z];
        best = z;
      }
    }
  }
  return best;
}

static void startWater(uint8_t z){
  if(ENFORCE_ONE_ZONE_AT_TIME && anyZoneWatering()){
    return;
  }
  hwSetValve(z, true);
  gState[z] = Z_WATERING;
  gStateSinceMs[z] = nowMs();
  gSessionStartMs[z] = nowMs();
  Serial.print(F("[WATER] Start Z"));
  Serial.println(z+1);
}

static void stopWater(uint8_t z){
  hwSetValve(z, false);
  gState[z] = Z_SOAK;
  gStateSinceMs[z] = nowMs();
  Serial.print(F("[WATER] Stop Z"));
  Serial.print(z+1);
  Serial.println(F(" -> SOAK"));
}

static void finishSession(uint8_t z){
  hwSetValve(z, false);
  gState[z] = Z_IDLE;
  gStateSinceMs[z] = nowMs();
  gLastWaterMs[z] = nowMs();
  gManualUntilMs[z] = 0;
  Serial.print(F("[WATER] Session end Z"));
  Serial.println(z+1);
}

static void loadDefaults(){
  gCfg.magic = CFG_MAGIC;
  gCfg.version = CFG_VERSION;
  for(uint8_t z=0; z<ZONE_COUNT; z++){
    // Default volutamente "non calibrato": auto irrigazione disabilitata finche' non fai cal dry/wet.
    gCfg.dryRaw[z] = 0;
    gCfg.wetRaw[z] = 0;
    gCfg.startPct[z] = DEFAULT_START_PCT[z];
    gCfg.stopPct[z]  = DEFAULT_STOP_PCT[z];
    gCfg.maxOnSec[z] = DEFAULT_MAX_ON_SEC[z];
    gCfg.soakSec[z]  = DEFAULT_SOAK_SEC[z];
  }
  gCfg.cooldownMin = DEFAULT_COOLDOWN_MIN;
}

static void loadConfig(){
  PersistData tmp;
  if(hwLoadPersist(tmp) && tmp.magic == CFG_MAGIC && tmp.version == CFG_VERSION){
    gCfg = tmp;
    Serial.println(F("[CFG] Loaded from NVM"));
  }else{
    loadDefaults();
    hwSavePersist(gCfg);
    Serial.println(F("[CFG] Defaults written to NVM"));
  }
}

static void printStatus(){
  Serial.println(F("=== STATUS ==="));
  Serial.print(F("Board: ")); Serial.println(hwBoardName());
  Serial.print(F("Mode: ")); Serial.println(gManualMode ? F("MANUAL") : F("AUTO"));
  Serial.print(F("Rain active: ")); Serial.println(hwReadRainActive() ? F("YES") : F("NO"));
  for(uint8_t z=0; z<ZONE_COUNT; z++){
    Serial.print(F("Z")); Serial.print(z+1);
    Serial.print(F(" raw=")); Serial.print(gSoilRaw[z]);
    Serial.print(F(" pct="));
    if(isfinite(gSoilPct[z])) Serial.print(gSoilPct[z],1); else Serial.print(F("NaN"));
    Serial.print(F(" calibrated=")); Serial.print(isCalibrated(z) ? F("YES") : F("NO"));
    Serial.print(F(" state=")); Serial.print((int)gState[z]);
    Serial.print(F(" start=")); Serial.print(gCfg.startPct[z]);
    Serial.print(F(" stop=")); Serial.print(gCfg.stopPct[z]);
    Serial.print(F(" maxOnSec=")); Serial.print(gCfg.maxOnSec[z]);
    Serial.print(F(" soakSec=")); Serial.print(gCfg.soakSec[z]);
    Serial.print(F(" cooldownOk=")); Serial.println(isCooldownOk(z) ? F("YES") : F("NO"));
  }
  Serial.println(F("Tip: se calibrated=NO, esegui 'cal <z> dry' e 'cal <z> wet'."));
}

static void printHelp(){
  Serial.println(F("Comandi:"));
  Serial.println(F("  help"));
  Serial.println(F("  status"));
  Serial.println(F("  auto                 (torna in AUTO)"));
  Serial.println(F("  on <z> <sec>          (MANUAL, z=1..2)"));
  Serial.println(F("  off                   (MANUAL, chiude tutto)"));
  Serial.println(F("  cal <z> dry|wet        (salva raw corrente)"));
  Serial.println(F("  set <z> start <pct>"));
  Serial.println(F("  set <z> stop <pct>"));
  Serial.println(F("  set <z> maxon <sec>"));
  Serial.println(F("  set <z> soak <sec>"));
  Serial.println(F("  set cooldown <min>"));
  Serial.println(F("  save"));
  Serial.println(F("  factoryreset"));
}

static int tokenCount(const String &s){
  int n=0; bool inTok=false;
  for(uint16_t i=0;i<s.length();i++){
    char c=s[i];
    bool sp = (c==' '||c=='\t'||c=='\r'||c=='\n');
    if(!sp && !inTok){ inTok=true; n++; }
    if(sp) inTok=false;
  }
  return n;
}

static String tokenAt(const String &s, int idx){
  int cur=-1; int start=-1; bool inTok=false;
  for(uint16_t i=0;i<=s.length();i++){
    char c = (i==s.length()) ? ' ' : s[i];
    bool sp = (c==' '||c=='\t'||c=='\r'||c=='\n');
    if(!sp && !inTok){
      inTok=true; cur++; start=i;
    }
    if((sp || i==s.length()) && inTok){
      int end=i;
      if(cur==idx) return s.substring(start,end);
      inTok=false;
    }
  }
  return String("");
}

static void handleCommand(String line){
  line.trim();
  if(line.length()==0) return;
  int n = tokenCount(line);
  String cmd = tokenAt(line,0);
  cmd.toLowerCase();

  if(cmd=="help"){ printHelp(); return; }
  if(cmd=="status"){ printStatus(); return; }

  if(cmd=="auto"){
    gManualMode = false;
    valveAllOff();
    Serial.println(F("[MODE] AUTO"));
    return;
  }

  if(cmd=="off"){
    gManualMode = true;
    valveAllOff();
    Serial.println(F("[MANUAL] all off"));
    return;
  }

  if(cmd=="on" && n>=3){
    int z = tokenAt(line,1).toInt() - 1;
    int sec = tokenAt(line,2).toInt();
    if(z<0 || z>=ZONE_COUNT || sec<=0){
      Serial.println(F("ERR: on <z 1..2> <sec>"));
      return;
    }
    gManualMode = true;
    valveAllOff();
    startWater((uint8_t)z);
    gManualUntilMs[z] = nowMs() + (uint32_t)sec * 1000UL;
    return;
  }

  if(cmd=="cal" && n>=3){
    int z = tokenAt(line,1).toInt() - 1;
    String which = tokenAt(line,2); which.toLowerCase();
    if(z<0 || z>=ZONE_COUNT){
      Serial.println(F("ERR: cal <z 1..2> dry|wet"));
      return;
    }
    if(which=="dry"){
      gCfg.dryRaw[z] = (int16_t)gSoilRaw[z];
      Serial.print(F("[CAL] Z")); Serial.print(z+1); Serial.print(F(" dryRaw=")); Serial.println(gCfg.dryRaw[z]);
    }else if(which=="wet"){
      gCfg.wetRaw[z] = (int16_t)gSoilRaw[z];
      Serial.print(F("[CAL] Z")); Serial.print(z+1); Serial.print(F(" wetRaw=")); Serial.println(gCfg.wetRaw[z]);
    }else{
      Serial.println(F("ERR: cal <z> dry|wet"));
      return;
    }
    hwSavePersist(gCfg);
    return;
  }

  if(cmd=="set" && n>=3){
    String a1 = tokenAt(line,1);
    a1.toLowerCase();
    if(a1=="cooldown" && n>=3){
      int min = tokenAt(line,2).toInt();
      if(min<0) min=0;
      gCfg.cooldownMin = (uint16_t)min;
      hwSavePersist(gCfg);
      Serial.print(F("[SET] cooldownMin=")); Serial.println(gCfg.cooldownMin);
      return;
    }
    int z = a1.toInt() - 1;
    if(z<0 || z>=ZONE_COUNT){
      Serial.println(F("ERR: set <z 1..2> ... oppure set cooldown <min>"));
      return;
    }
    String what = tokenAt(line,2); what.toLowerCase();
    if(what=="start" && n>=4){
      int pct = tokenAt(line,3).toInt();
      gCfg.startPct[z] = (uint8_t)constrain(pct,0,100);
    }else if(what=="stop" && n>=4){
      int pct = tokenAt(line,3).toInt();
      gCfg.stopPct[z] = (uint8_t)constrain(pct,0,100);
    }else if(what=="maxon" && n>=4){
      int sec = tokenAt(line,3).toInt();
      gCfg.maxOnSec[z] = (uint16_t)max(1, sec);
    }else if(what=="soak" && n>=4){
      int sec = tokenAt(line,3).toInt();
      gCfg.soakSec[z] = (uint16_t)max(0, sec);
    }else{
      Serial.println(F("ERR: set <z> start|stop|maxon|soak <val>"));
      return;
    }
    hwSavePersist(gCfg);
    Serial.println(F("[SET] OK"));
    return;
  }

  if(cmd=="save"){
    hwSavePersist(gCfg);
    Serial.println(F("[CFG] saved"));
    return;
  }

  if(cmd=="factoryreset"){
    loadDefaults();
    hwSavePersist(gCfg);
    Serial.println(F("[CFG] factory reset done"));
    return;
  }

  Serial.println(F("Comando sconosciuto. Digita 'help'."));
}

static void serialTask(){
  while(Serial.available()){
    char c = (char)Serial.read();
    if(c=='\n'){
      handleCommand(gLine);
      gLine = "";
    }else if(c!='\r'){
      if(gLine.length() < 120) gLine += c;
    }
  }
}

static void sensorTask(){
  static uint32_t last = 0;
  if(nowMs() - last < SENSOR_READ_EVERY_MS) return;
  last = nowMs();
  for(uint8_t z=0; z<ZONE_COUNT; z++){
    gSoilRaw[z] = hwReadSoilRaw(z);
    if(isCalibrated(z)) gSoilPct[z] = rawToPct(gSoilRaw[z], gCfg.dryRaw[z], gCfg.wetRaw[z]);
    else gSoilPct[z] = NAN;
  }
}

static void debugTask(){
  static uint32_t last = 0;
  if(nowMs() - last < DEBUG_PRINT_EVERY_MS) return;
  last = nowMs();
  Serial.print(F("[DBG] "));
  for(uint8_t z=0; z<ZONE_COUNT; z++){
    Serial.print(F("Z")); Serial.print(z+1);
    Serial.print(F("="));
    if(isfinite(gSoilPct[z])) Serial.print(gSoilPct[z],1); else Serial.print(F("NaN"));
    Serial.print(F("% "));
  }
  Serial.print(F("mode=")); Serial.print(gManualMode ? "MAN":"AUT");
  Serial.print(F(" rain=")); Serial.print(hwReadRainActive()? "1":"0");
  Serial.print(F(" stop=")); Serial.println(hwReadStopActive()? "1":"0");
}

static void irrigationTask(){
  // STOP button has priority
  if(USE_STOP_BUTTON && hwReadStopActive()){
    valveAllOff();
    gManualMode = true;
    Serial.println(F("[STOP] Premuto: tutto OFF (manual mode)"));
    return;
  }

  // Rain lock (optional)
  if(USE_RAIN_SENSOR && hwReadRainActive()){
    valveAllOff();
    return;
  }

  // Gestione stati per zona
  for(uint8_t z=0; z<ZONE_COUNT; z++){
    if(gState[z]==Z_WATERING){
      uint32_t onFor = (nowMs() - gStateSinceMs[z]) / 1000UL;
      uint32_t sessionFor = (nowMs() - gSessionStartMs[z]) / 1000UL;

      // manual stop time
      if(gManualMode && gManualUntilMs[z] != 0 && nowMs() >= gManualUntilMs[z]){
        finishSession(z);
        continue;
      }

      // sicurezza: limite assoluto sessione
      if(sessionFor >= ABSOLUTE_SESSION_LIMIT_SEC){
        Serial.println(F("[SAFE] Session limit reached -> OFF"));
        finishSession(z);
        continue;
      }

      // stop condition: sopra stopPct (solo in auto) oppure tempo max ciclo
      if(!gManualMode && isfinite(gSoilPct[z]) && gSoilPct[z] >= float(gCfg.stopPct[z])){
        Serial.println(F("[AUTO] stop threshold reached"));
        finishSession(z);
        continue;
      }
      if(onFor >= gCfg.maxOnSec[z]){
        stopWater(z);
        continue;
      }
    } else if(gState[z]==Z_SOAK){
      uint32_t soakFor = (nowMs() - gStateSinceMs[z]) / 1000UL;
      if(soakFor >= gCfg.soakSec[z]){
        // fine soak: in auto rivaluta, in manual chiude
        if(gManualMode){
          finishSession(z);
        }else{
          if(isfinite(gSoilPct[z]) && gSoilPct[z] < float(gCfg.stopPct[z])){
            startWater(z);
          }else{
            finishSession(z);
          }
        }
      }
    }
  }

  // In AUTO: se nessuno sta irrigando, scegli una zona che richiede acqua
  if(!gManualMode){
    if(!anyZoneWatering()){
      int z = driestZoneReady();
      if(z>=0) startWater((uint8_t)z);
    }
  }
}

void logicSetup(){
  Serial.begin(SERIAL_BAUD);
  delay(80);
  Serial.println();
  Serial.println(F("=== IrrigationSmart BOOT ==="));
  Serial.print(F("Board: ")); Serial.println(hwBoardName());

  loadConfig();

  for(uint8_t z=0; z<ZONE_COUNT; z++){
    gState[z] = Z_IDLE;
    gStateSinceMs[z] = nowMs();
    gLastWaterMs[z] = 0;
    gSessionStartMs[z] = 0;
    gManualUntilMs[z] = 0;
    gSoilRaw[z] = 0;
    gSoilPct[z] = NAN;
  }

  printHelp();
}

void logicLoop(){
  serialTask();
  sensorTask();
  irrigationTask();
  debugTask();
}
