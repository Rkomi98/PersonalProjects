# Voxtral Terminal Backend

Backend locale in Python 3.11, pensato per essere testato da terminale.

Cosa fa:
- prepara un ambiente CLI per scaricare asset collegati a Voxtral
- usa `datapizza-ai` per il parsing del markdown e la costruzione dello script da leggere
- usa `audio.wav` come reference voice per generare un file audio parlato

Nota importante:
- lo Space pubblico [mistralai/voxtral-tts-demo](https://huggingface.co/spaces/mistralai/voxtral-tts-demo) esiste davvero
- nel progetto lascio il download di Voxtral come asset on-demand tramite Hugging Face
- la sintesi/voice cloning locale viene eseguita con `chatterbox-tts`, perché il flusso di clonazione voce è disponibile e testabile in locale con Python 3.11

## Setup

```bash
python3.11 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
cp .env.example .env
```

## Comandi

Scarica gli asset:

```bash
.venv/bin/voxtral-backend download
```

Estrai e ispeziona il testo "speakable" dal markdown usando `datapizza-ai`:

```bash
.venv/bin/voxtral-backend extract-text --markdown samples/demo.md
```

Genera l'audio clonato:

```bash
.venv/bin/voxtral-backend speak \
  --markdown samples/demo.md \
  --reference-audio audio.wav \
  --output outputs/demo.wav
```

## File attesi

- `audio.wav`: il reference audio per clonare la voce
- `samples/demo.md`: esempio di markdown da leggere
- `outputs/demo.wav`: output generato

## Test

```bash
.venv/bin/pytest
```
