"""Pacchetto applicativo: TTS (Chatterbox) e integrazione Mistral."""

__all__: list[str] = []
